Starts a cluster via the discovery service on your local machine. Useful for testing.
